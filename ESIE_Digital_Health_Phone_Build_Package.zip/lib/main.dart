import 'package:flutter/material.dart';

void main() {
  runApp(const EsieDigitalHealthApp());
}

const esiePink = Color(0xFFE85D91);
const esieRed = Color(0xFFC62828);
const esieInk = Color(0xFF263238);
const esieBackground = Color(0xFFFFF7FA);

class EsieDigitalHealthApp extends StatelessWidget {
  const EsieDigitalHealthApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ESIE Digital Health',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: esieBackground,
        colorScheme: ColorScheme.fromSeed(
          seedColor: esiePink,
          primary: esiePink,
          secondary: esieRed,
          surface: Colors.white,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: esieInk,
          centerTitle: false,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFE8DDE2)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFE8DDE2)),
          ),
        ),
      ),
      home: const WelcomePage(),
    );
  }
}

class WelcomePage extends StatelessWidget {
  const WelcomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Spacer(),
              Container(
                height: 112,
                width: 112,
                alignment: Alignment.center,
                decoration: const BoxDecoration(
                  color: esiePink,
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.favorite, color: Colors.white, size: 58),
              ),
              const SizedBox(height: 24),
              const Text(
                'ESIE DIGITAL HEALTH',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: esieRed,
                  fontSize: 25,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.1,
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                'Connecting mothers to better healthcare.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, color: esieInk),
              ),
              const SizedBox(height: 28),
              const InfoBanner(
                text: 'Health education saved in this app can be viewed offline.',
                icon: Icons.wifi_off,
              ),
              const SizedBox(height: 22),
              FilledButton(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const RolePage()),
                ),
                child: const Padding(
                  padding: EdgeInsets.all(14),
                  child: Text('Get started'),
                ),
              ),
              const Spacer(),
              const Text(
                'Prototype version • English',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.black54, fontSize: 12),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class RolePage extends StatelessWidget {
  const RolePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Choose your access')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text(
            'Who are you?',
            style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          const Text('Select the section you want to open.'),
          const SizedBox(height: 20),
          RoleCard(
            icon: Icons.pregnant_woman,
            title: 'Mother',
            subtitle: 'Pregnancy, appointments and baby-care information',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const MotherRegisterPage()),
            ),
          ),
          RoleCard(
            icon: Icons.medical_services_outlined,
            title: 'Nurse / Midwife',
            subtitle: 'For authorised maternity staff',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const StaffNoticePage(role: 'Nurse / Midwife'),
              ),
            ),
          ),
          RoleCard(
            icon: Icons.admin_panel_settings_outlined,
            title: 'Administrator',
            subtitle: 'Staff account and facility administration',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const StaffNoticePage(role: 'Administrator'),
              ),
            ),
          ),
          const SizedBox(height: 12),
          const InfoBanner(
            text: 'Staff sign-in is not connected yet. In the production system, the ESIE administrator will create and approve staff accounts.',
            icon: Icons.lock_outline,
          ),
        ],
      ),
    );
  }
}

class MotherRegisterPage extends StatefulWidget {
  const MotherRegisterPage({super.key});

  @override
  State<MotherRegisterPage> createState() => _MotherRegisterPageState();
}

class _MotherRegisterPageState extends State<MotherRegisterPage> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _phone = TextEditingController();

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mother registration')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Text(
              'Welcome to ESIE',
              style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text('This is a demonstration form. Do not enter real patient details yet.'),
            const SizedBox(height: 22),
            TextFormField(
              controller: _name,
              decoration: const InputDecoration(
                labelText: 'Full name',
                prefixIcon: Icon(Icons.person_outline),
              ),
              validator: (v) => (v == null || v.trim().isEmpty)
                  ? 'Enter a name to continue'
                  : null,
            ),
            const SizedBox(height: 14),
            TextFormField(
              controller: _phone,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(
                labelText: 'Phone number',
                prefixIcon: Icon(Icons.phone_outlined),
                hintText: 'e.g. 07XXXXXXXX',
              ),
              validator: (v) => (v == null || v.trim().length < 9)
                  ? 'Enter a valid phone number'
                  : null,
            ),
            const SizedBox(height: 14),
            const InfoBanner(
              text: 'Pregnancy dates and medical records are not collected in this prototype.',
              icon: Icons.privacy_tip_outlined,
            ),
            const SizedBox(height: 22),
            FilledButton(
              onPressed: () {
                if (_formKey.currentState!.validate()) {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (_) => MotherHomePage(name: _name.text.trim()),
                    ),
                  );
                }
              },
              child: const Padding(
                padding: EdgeInsets.all(14),
                child: Text('Continue to demo'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class MotherHomePage extends StatelessWidget {
  final String name;
  const MotherHomePage({super.key, required this.name});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ESIE Digital Health'),
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 16),
            child: Icon(Icons.wifi_off, color: esieRed),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Text(
            'Hello, $name',
            style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 5),
          const Text('Your maternal health companion'),
          const SizedBox(height: 18),
          const InfoBanner(
            text: 'Offline demo: the educational information below is built into the app.',
            icon: Icons.wifi_off,
          ),
          const SizedBox(height: 18),
          const SectionTile(
            icon: Icons.calendar_month,
            title: 'ANC appointments',
            subtitle: 'Appointment scheduling will be available after clinic connection is set up.',
          ),
          SectionTile(
            icon: Icons.favorite_border,
            title: 'Pregnancy education',
            subtitle: 'Read general information about staying well during pregnancy.',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const EducationPage(category: 'Pregnancy'),
              ),
            ),
          ),
          SectionTile(
            icon: Icons.child_care,
            title: 'Newborn and baby care',
            subtitle: 'Basic newborn care and warning signs.',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const EducationPage(category: 'Newborn care'),
              ),
            ),
          ),
          SectionTile(
            icon: Icons.health_and_safety_outlined,
            title: 'When to seek urgent care',
            subtitle: 'Important warning signs for mothers and newborns.',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const EducationPage(category: 'Urgent warning signs'),
              ),
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'For emergencies, go to the nearest health facility immediately. This app does not provide emergency diagnosis.',
            style: TextStyle(color: esieRed, fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }
}

class EducationPage extends StatelessWidget {
  final String category;
  const EducationPage({super.key, required this.category});

  @override
  Widget build(BuildContext context) {
    final content = switch (category) {
      'Pregnancy' => const [
          'Attend antenatal care (ANC) visits as advised by a qualified health worker.',
          'Eat a varied diet and drink safe water.',
          'Take only medicines and supplements recommended by a qualified health worker.',
          'Ask your health worker about birth preparedness and where to seek care.',
        ],
      'Newborn care' => const [
          'Keep the baby warm and practise skin-to-skin contact when appropriate.',
          'Breastfeed as soon as possible after birth and exclusively breastfeed for the first six months, unless a qualified clinician advises otherwise.',
          'Attend newborn checks and follow the national immunisation schedule.',
          'Seek care promptly if the baby is not feeding well, has difficulty breathing, has fever or feels unusually cold, or is unusually sleepy.',
        ],
      _ => const [
          'During pregnancy, seek urgent care for vaginal bleeding, severe abdominal pain, severe headache or blurred vision, difficulty breathing, convulsions, or reduced/absent fetal movement.',
          'After birth, seek urgent care for heavy bleeding, fever, severe headache or blurred vision, difficulty breathing, or severe abdominal pain.',
          'For a newborn, seek urgent care for difficulty breathing, convulsions, inability to feed, fever or unusually low temperature, or extreme sleepiness.',
          'Do not wait for an app response when a danger sign is present. Go to the nearest health facility or contact local emergency services.',
        ],
    };

    return Scaffold(
      appBar: AppBar(title: Text(category)),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const InfoBanner(
            text: 'Saved information: this page is available without an internet connection.',
            icon: Icons.offline_pin_outlined,
          ),
          const SizedBox(height: 16),
          ...content.map(
            (item) => Card(
              color: Colors.white,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(Icons.check_circle_outline, color: esiePink),
                    const SizedBox(width: 12),
                    Expanded(child: Text(item, style: const TextStyle(height: 1.4))),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'Educational content must be reviewed and approved by ESIE clinical leadership before public release.',
            style: TextStyle(fontSize: 12, color: Colors.black54),
          ),
        ],
      ),
    );
  }
}

class StaffNoticePage extends StatelessWidget {
  final String role;
  const StaffNoticePage({super.key, required this.role});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(role)),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Icon(Icons.lock_person_outlined, size: 58, color: esiePink),
            const SizedBox(height: 18),
            Text(
              '$role access',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            const Text(
              'This section is a placeholder in the starter build. In the live system, staff accounts will be created and approved by the ESIE administrator, with role-based permissions and secure sign-in.',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 18),
            const InfoBanner(
              text: 'No real patient records or staff credentials are stored in this prototype.',
              icon: Icons.security,
            ),
          ],
        ),
      ),
    );
  }
}

class RoleCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const RoleCard({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        contentPadding: const EdgeInsets.all(16),
        leading: CircleAvatar(
          backgroundColor: const Color(0xFFFFE2EC),
          child: Icon(icon, color: esieRed),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Text(subtitle),
        ),
        trailing: const Icon(Icons.arrow_forward_ios, size: 16),
        onTap: onTap,
      ),
    );
  }
}

class SectionTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback? onTap;

  const SectionTile({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        contentPadding: const EdgeInsets.all(14),
        leading: CircleAvatar(
          backgroundColor: const Color(0xFFFFE2EC),
          child: Icon(icon, color: esieRed),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Text(subtitle),
        ),
        trailing: onTap == null ? null : const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    );
  }
}

class InfoBanner extends StatelessWidget {
  final String text;
  final IconData icon;
  const InfoBanner({super.key, required this.text, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFEAF1),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: esieRed),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: const TextStyle(height: 1.35))),
        ],
      ),
    );
  }
}
