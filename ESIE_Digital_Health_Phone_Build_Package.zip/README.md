# ESIE Digital Health — phone-based APK build package

This is a first Flutter UI prototype. It includes a welcome screen, mother demo registration,
mother dashboard, built-in offline education pages, and placeholder staff/admin sections.

IMPORTANT: This is not a production clinical system. Do not enter real patient information.
Staff authentication, a live database, encrypted medical records, appointment notifications,
and cloud synchronisation are not implemented. Clinical content must be reviewed by ESIE's
qualified clinical lead before public release. Comply with Uganda's data protection rules
before handling real health data.

## Build an APK using only an Android phone

1. Open github.com in Chrome on your phone and sign in or create a GitHub account.
2. Create a new repository called `esie-digital-health`.
3. Extract this ZIP using your phone's Files / My Files app.
4. In the repository, tap **Add file → Upload files** and upload the files/folders while
   preserving these paths:
   - `pubspec.yaml`
   - `README.md`
   - `lib/main.dart`
   - `.github/workflows/android-apk.yml`
   If folder upload is unavailable on mobile, turn on Chrome's **Desktop site** option.
5. Commit the files to the `main` branch.
6. Open the repository's **Actions** tab. Select **Build ESIE Digital Health APK**.
   If needed, tap **Run workflow**.
7. Wait for a successful run, open it, and download the artifact
   `ESIE-Digital-Health-APK`.
8. Extract the downloaded artifact ZIP. Tap `app-release.apk` to install it.
   Android may ask you to allow installs from Chrome or your Files app.

The workflow compiles the APK on GitHub's cloud computer; you do not need your own computer.
